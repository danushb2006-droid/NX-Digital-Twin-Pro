# NX-DIGITAL TWIN PRO v3.2

A mobile-first mechanical digital-twin demonstration built with Vite, Three.js, Chart.js and Capacitor.

## Included
- Interactive conceptual 3D gear-reduction assembly (orbit, zoom, component selection)
- Exploded-view slider and seven-step assembly guide
- Wireframe and section clipping modes
- Standard and illustrative stress/heat color modes
- Simulated motor RPM, output RPM, vibration spectrum and temperature
- Fault injection and diagnostic event log
- Responsive Android-friendly interface

## Important engineering notes
This is a demonstration model, not production CAD geometry. The stress/heat colors are illustrative and are not validated FEA results. Telemetry and fault injection are simulated; no physical sensors or IoT device are connected. The AR button opens a spatial-preview overlay only. It does not perform camera tracking or true augmented reality.

## Build and run on a computer
Install Node.js LTS and Android Studio.

```bash
npm install
npm run dev
```

Open the local address printed by Vite to preview in a browser.

## Build Android project
Install Android Studio with Android SDK and a compatible JDK (Android Studio's bundled JDK is recommended).

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio:
1. Wait for Gradle sync to finish.
2. Connect your Redmi 10 with USB debugging enabled, or use an emulator.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a test APK.
4. For a distributable APK, select **Build > Generate Signed Bundle / APK > APK**, create and safely store a release keystore, and build the release variant.
5. Android Studio shows the APK location when the build finishes.

For later web changes:
```bash
npm run android:sync
```

## Redmi 10 testing
- Install the debug APK on Android 13.
- Allow installation from the file manager/browser used to open the APK.
- Test touch orbit, pinch zoom, tabs, slider controls, chart, and fault toggles.
- If rendering is slow, close background apps and lower Android Studio/device graphics load.

## App identity
- Display name: NX Digital Twin Pro
- Android application ID: `com.nxdigitaltwin.pro`


## Build APK using only your phone (GitHub Actions)
This project includes `.github/workflows/android-apk.yml`.
1. Create a GitHub repository from your phone.
2. Upload the project files and folders to the repository (extract the ZIP first; upload the contents, including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `NX-Digital-Twin-Pro-debug-apk`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it on your Android phone.

The workflow creates a debug APK for testing. A release APK signed with your own private keystore is required for public distribution and updates outside your own test installation.
